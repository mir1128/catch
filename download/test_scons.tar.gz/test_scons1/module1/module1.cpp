#include "module1.h"
#include "base.h"

void module1()
{
    cout << "this is module1" << endl;
}
