#ifndef __SUB_H_
#define __SUB_H_

int sub(int a, int b);

#endif
