#ifndef __ADD_H_
#define __ADD_H_

int add(int a, int b);

#endif
