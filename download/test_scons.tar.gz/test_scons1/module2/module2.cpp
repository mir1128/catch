#include "module1.h"
#include "base.h"

void module2()
{
    cout << "this is module1" << endl;
}
