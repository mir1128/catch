#ifndef __MODULE1_H_
#define __MODULE1_H_

void module1();

#endif