#ifndef __BASH_H_
#define __BASH_H_

#include "iostream"
using namespace std;

#endif
