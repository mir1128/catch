#ifndef __MODULE2_H_
#define __MODULE2_H_

void module2();

#endif